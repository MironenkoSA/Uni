package ch.makery.address;

import java.io.IOException;
import java.io.File;  // Для класса File

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import ch.makery.address.model.Club;
import ch.makery.address.model.ClubListWrapper;
import ch.makery.address.view.ClubOverviewController;
import ch.makery.address.view.ClubEditDialogController;
import ch.makery.address.view.RootLayoutController;

import java.util.prefs.Preferences;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;


public class MainApp extends Application {

    private Stage primaryStage;
    private BorderPane rootLayout;

    /**
     * The data as an observable list of Clubs.
     */
    private ObservableList<Club> RestarauntData = FXCollections.observableArrayList();

    /**
     * Constructor
     */
    public MainApp() {
        // Add some sample data
        RestarauntData.add(new Restaraunt("Ресторан 1", "Улица пушкина \"89998887733\""));
        RestarauntData.add(new Restaraunt("Ресторан 2", "Улица птушкина \"89998887722\""));
        RestarauntData.add(new Restaraunt("Ресторан 3", "Улица театральная \"89998887711\""));
        RestarauntData.add(new Restaraunt("Ресторан 4", "Улица декана \"89998887744\""));
        RestarauntData.add(new Restaraunt("Ресторан 5", "Улица программирования \"89998887755\""));
        RestarauntData.add(new Restaraunt("Ресторан 6", "Улица архонта \"89998887766\""));
        RestarauntData.add(new Restaraunt("Ресторан 7", "Улица шахматная \"89998887799\""));
        RestarauntData.add(new Restaraunt("Ресторан 8", "Улица фотоискусства \"89998887788\""));
    }


    public ObservableList<Club> getRestarauntData() {
        return RestarauntData;
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("RestarauntApp");

        this.primaryStage.getIcons().add(new Image("2124225_card_essential_app_credit_icon.png"));

        initRootLayout();

        showClubOverview();
    }

    /**
     * Initializes the root layout.
     */
    public void initRootLayout() {
        try {
            // Load root layout from fxml file.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/ch/makery/address/viev/RootLayout.fxml"));
            rootLayout = (BorderPane) loader.load();

            // Show the scene containing the root layout.
            //Scene scene = new Scene(rootLayout);
            //primaryStage.setScene(scene);
            primaryStage.setScene(new Scene(rootLayout, 1200 , 520));
            primaryStage.setResizable(false);
            RootLayoutController controller = loader.getController();
            controller.setMainApp(this);
            primaryStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Пытается загрузить последний открытый файл с адресатами.
        File file = getClubFilePath();
        if (file != null) {
            loadClubDataFromFile(file);
        }
    }

      /**SS
     * Shows the Restaraunt overview inside the root layout.
     */
    public void showRestarauntOverview() {
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MainApp.class.getResource("/ch/makery/address/viev/RestarauntOverview.fxml"));
            AnchorPane RestarauntOverview = (AnchorPane) loader.load();

            rootLayout.setCenter(RestarauntOverview);

            ClubOverviewController controller = loader.getController();
            controller.setMainApp(this);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public boolean showClubEditDialog(Restaraunt restaraunt) {
        try {
            // Загружаем fxml-файл и создаём новую сцену
            // для всплывающего диалогового окна.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/ch/makery/address/viev/ClubEditDialog.fxml"));
            AnchorPane page = (AnchorPane) loader.load();

            // Создаём диалоговое окно Stage.
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Edit Club");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Передаём адресата в контроллер.
            ClubEditDialogController controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setClub(restaraunt);

            // Отображаем диалоговое окно и ждём, пока пользователь его не закроет
            dialogStage.showAndWait();

            return controller.isOkClicked();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }


    public File getRestarauntFilePath() {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        String filePath = prefs.get("filePath", null);
        if (filePath != null) {
            return new File(filePath);
        } else {
            return null;
        }
    }


    public void setResatauntFilePath(File file) {
        Preferences prefs = Preferences.userNodeForPackage(MainApp.class);
        if (file != null) {
            prefs.put("filePath", file.getPath());
            System.out.println("File path saved: " + file.getPath());

            // Обновление заглавия сцены.
            primaryStage.setTitle("RestarauntApp - " + file.getName());
        } else {
            prefs.remove("filePath");
            System.out.println("File path removed");

            // Обновление заглавия сцены.
            primaryStage.setTitle("ClubApp");
        }
    }
    /**
     * Загружает информацию об адресатах из указанного файла.
     * Текущая информация об адресатах будет заменена.
     *
     * @param file
     */
    public void loadRestarauntDataFromFile(File file) {
        try {
            JAXBContext context = JAXBContext
                    .newInstance(RestarauntListWrapper.class);
            Unmarshaller um = context.createUnmarshaller();

            // Чтение XML из файла и демаршализация.
            RestarauntListWrapper wrapper = (RestarauntListWrapper) um.unmarshal(file);

            RestarauntData.clear();
            RestarauntData.addAll(wrapper.getRestaraunts());

            // Сохраняем путь к файлу в реестре.
            setRestarauntFilePath(file);

        } catch (Exception e) { // catches ANY exception
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not load data");
            alert.setContentText("Could not load data from file:\n" + file.getPath());

            alert.showAndWait();
        }
    }

    /**
     * Сохраняет текущую информацию об адресатах в указанном файле.
     *
     * @param file
     */
    public void saveClubDataToFile(File file) {
        try {
            JAXBContext context = JAXBContext.newInstance(ClubListWrapper.class);
            Marshaller m = context.createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            // Обёртываем наши данные об адресатах.
            ClubListWrapper wrapper = new ClubListWrapper();
            wrapper.setClubs(ClubData);

            // Маршаллируем и сохраняем XML в файл.
            m.marshal(wrapper, file);

            // Сохраняем путь к файлу в реестре.
            setClubFilePath(file);
        } catch (Exception e) {
            // Вывод информации об ошибке в консоль
            e.printStackTrace();

            // Создание уведомления об ошибке
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Could not save data");
            alert.setContentText("Could not save data to file:\n" + file.getPath() + "\nError: " + e.getMessage());

            alert.showAndWait();
        }
    }
    
    public Stage getPrimaryStage() {
        return primaryStage;
    }

    public static void main(String[] args) {
        launch(args);
    }
}